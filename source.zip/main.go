package main
import (
	"log"
	"net/http"
	"image/png"
	"image"
	"os"
	"strconv"
//	"math/rand"
)
//modle size 64x128 px
var modle=[...]string{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","AA","BB","CC","DD","EE","FF","GG","HH","II","JJ","KK","LL","MM","NN","OO","PP","QQ","RR","SS","TT","UU","VV","WW","XX","YY","ZZ","0","1","2","3","4","5","6","7","8","9"}
var files [62]image.Image

func init_server(){
	log.Println("start running")
	length:=len(modle)
	var i int=0
	var name string
	for i<length{
		name=modle[i]+".png"
		log.Println("reading and encode file: "+name)
		tmp,_:=os.Open("./z/"+name)
		defer tmp.Close()
		files[i],_=png.Decode(tmp)
		i++
	}
	log.Println(files,"***Decode images done!!!")
}
func choose(data_byte byte)(int){
	data:=int(data_byte)
	if data>=97{//为小写
		return data-97
	}
	if data<=90 && data >=65{
		return data-65+26
	}
	if data<=57 && data>=48{
		return data-48+52
	}
	return 0
}
func pic(w http.ResponseWriter,r *http.Request){
	r.ParseForm()
	var NumOfModle int
	NumOfModle,_=strconv.Atoi(r.FormValue("num"))
	word:=r.FormValue("word")
	if word=="" || r.FormValue("num")=="" || len(word)<NumOfModle{
		w.Write([]byte("error"))
		log.Panic("error")
	}
	word=word[:NumOfModle]
	output:=image.NewRGBA(image.Rect(0,0,64*NumOfModle,128))
	var i=0
	var width,longth int=0,0
	//var choose int32=0
	var result string=""
	for i<NumOfModle {
		//choose=rand.Int31n(60)
		result+=modle[choose(word[i])]
		for width<=128{
			for longth=0+i*64;longth<=(i+1)*64;longth++{
				output.Set(longth,width,files[choose(word[i])].At(longth-i*64,width))
			}
			width++
		}
		width=0
		i++
	} 
	log.Println(result)
	w.Header().Set("Content-Type", "image/png")
	png.Encode(w,output)
}

func main(){
	init_server()
	http.HandleFunc("/pic",pic)
	http.ListenAndServe(":8080",nil)
}
