package main
import (
	"log"
//	"io/ioutil"
	"image/png"
	"image"
	"os"
//	"strconv"
	"math/rand"
)
//modle size 64x128 px
const NumOfModle int=4
func main(){
	log.Println("start running")
	modle:=[...]string{"1","2","3","4","5","6","7","8","9","0","q","QQ","w","WW","e","EE","r","RR","t","TT","y","YY","u","UU","i","II","o","OO","p","PP","a","AA","s","SS","d","DD","f","FF","g","GG","h","HH","j","JJ","l","LL","z","ZZ","x","XX","c","CC","v","VV","b","BB","n","NN","m","MM"}
	length:=len(modle)
	var files [60]image.Image
	var i int=0
	var name string
	for i<length{
		name=modle[i]+".png"
		log.Println("reading file "+name)
		tmp,_:=os.Open("./z/"+name)
		files[i],_=png.Decode(tmp)
		i++
	}
	log.Println(files,"***Decode images done!!!")
	output:=image.NewRGBA(image.Rect(0,0,64*NumOfModle,128))
	i=0
	var width,longth int=0,0
	var choose int32=0
	var result string=""
	for i<NumOfModle {
		choose=rand.Int31n(60)
		result+=modle[choose]
		for width<=128{
			for longth=0+i*64;longth<=(i+1)*64;longth++{
				output.Set(longth,width,files[choose].At(longth-i*64,width))
			}
			width++
		}
		width=0
		i++
	} 
	log.Println(result)
	op,_:=os.Create(result+".png")
	png.Encode(op,output)
}
