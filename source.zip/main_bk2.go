package main
import (
	"log"
	"net/http"
	"image/png"
	"image"
	"os"
	"strconv"
	"math/rand"
)
//modle size 64x128 px
var modle=[...]string{"1","2","3","4","5","6","7","8","9","0","q","QQ","w","WW","e","EE","r","RR","t","TT","y","YY","u","UU","i","II","o","OO","p","PP","a","AA","s","SS","d","DD","f","FF","g","GG","h","HH","j","JJ","l","LL","z","ZZ","x","XX","c","CC","v","VV","b","BB","n","NN","m","MM"}
var files [60]image.Image

func init_server(){
	log.Println("start running")
		length:=len(modle)
	var i int=0
	var name string
	for i<length{
		name=modle[i]+".png"
		log.Println("reading file "+name)
		tmp,_:=os.Open("./z/"+name)
		defer tmp.Close()
		files[i],_=png.Decode(tmp)
		i++
	}
	log.Println(files,"***Decode images done!!!")
}

func pic(w http.ResponseWriter,r *http.Request){
	r.ParseForm()

	var NumOfModle int
	NumOfModle,_=strconv.Atoi(r.FormValue("num"))
	output:=image.NewRGBA(image.Rect(0,0,64*NumOfModle,128))
	var i=0
	var width,longth int=0,0
	var choose int32=0
	var result string=""
	for i<NumOfModle {
		choose=rand.Int31n(60)
		result+=modle[choose]
		for width<=128{
			for longth=0+i*64;longth<=(i+1)*64;longth++{
				output.Set(longth,width,files[choose].At(longth-i*64,width))
			}
			width++
		}
		width=0
		i++
	} 
	log.Println(result)
	//op,_:=os.Create(result+".png")
	//defer op.Close()
	w.Header().Set("Content-Type", "image/png")
	png.Encode(w,output)
}

func main(){
	init_server()
	http.HandleFunc("/pic",pic)
	http.ListenAndServe(":8080",nil)
}
